package com.gremio.ciber_web.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Renta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private int numeroPc;
    private String nombreCliente;
    private int tiempoMinutos;
    private double totalPagar;

    // Genera aquí los Getters y Setters (o usa los atajos de VS Code)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public int getNumeroPc() { return numeroPc; }
    public void setNumeroPc(int numeroPc) { this.numeroPc = numeroPc; }
    
    public String getNombreCliente() { return nombreCliente; }
    public void setNombreCliente(String nombreCliente) { this.nombreCliente = nombreCliente; }
    
    public int getTiempoMinutos() { return tiempoMinutos; }
    public void setTiempoMinutos(int tiempoMinutos) { this.tiempoMinutos = tiempoMinutos; }
    
    public double getTotalPagar() { return totalPagar; }
    public void setTotalPagar(double totalPagar) { this.totalPagar = totalPagar; }
}