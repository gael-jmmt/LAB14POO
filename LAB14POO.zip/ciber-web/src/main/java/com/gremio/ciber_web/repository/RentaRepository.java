package com.gremio.ciber_web.repository;

import com.gremio.ciber_web.model.Renta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RentaRepository extends JpaRepository<Renta, Long> {
}