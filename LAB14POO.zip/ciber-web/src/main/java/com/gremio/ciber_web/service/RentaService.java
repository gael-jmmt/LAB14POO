package com.gremio.ciber_web.service;

import com.gremio.ciber_web.model.Renta;
import com.gremio.ciber_web.repository.RentaRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RentaService {
    private final RentaRepository repo;

    public RentaService(RentaRepository repo) {
        this.repo = repo;
    }

    public List<Renta> listarTodas() {
        return repo.findAll();
    }

    public void guardar(Renta renta) {
        // Pequeña lógica automática: si la hora cuesta $15 pesos (0.25 el minuto)
        if(renta.getTotalPagar() == 0) {
            renta.setTotalPagar(renta.getTiempoMinutos() * 0.25);
        }
        repo.save(renta);
    }

    public Renta buscarPorId(Long id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Renta no encontrada"));
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}