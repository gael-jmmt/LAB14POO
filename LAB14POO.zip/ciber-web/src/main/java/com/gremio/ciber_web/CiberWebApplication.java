package com.gremio.ciber_web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiberWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(CiberWebApplication.class, args);
	}

}
