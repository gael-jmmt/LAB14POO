package com.gremio.ciber_web.controller;

import com.gremio.ciber_web.model.Renta;
import com.gremio.ciber_web.service.RentaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RentaController {
    private final RentaService service;

    public RentaController(RentaService service) {
        this.service = service;
    }

    @GetMapping("/rentas")
    public String listar(Model model) {
        model.addAttribute("rentas", service.listarTodas());
        return "rentas";
    }

    @GetMapping("/nuevo")
    public String formularioNuevo(Model model) {
        model.addAttribute("renta", new Renta());
        return "formulario";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Renta renta) {
        service.guardar(renta);
        return "redirect:/rentas";
    }

    @GetMapping("/editar/{id}")
    public String formularioEditar(@PathVariable Long id, Model model) {
        model.addAttribute("renta", service.buscarPorId(id));
        return "formulario";
    }

    @PostMapping("/actualizar")
    public String actualizar(@ModelAttribute Renta renta) {
        service.guardar(renta);
        return "redirect:/rentas";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return "redirect:/rentas";
    }
}