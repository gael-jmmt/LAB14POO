package com.gremio.ciber_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CiberWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
